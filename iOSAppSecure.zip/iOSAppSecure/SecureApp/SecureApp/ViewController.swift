//
//  ViewController.swift
//  SecureApp
//
//  Created by sergio antonio rodriguez rodriguez on 5/25/19.
//  Copyright © 2019 sergio antonio rodriguez rodriguez. All rights reserved.
//

import UIKit
import MapKit
class ViewController: UIViewController {

    @IBOutlet weak var mapita: MKMapView!
    
    
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var phone: UITextField!
    @IBOutlet weak var pass: UITextField!
    @IBOutlet weak var mail: UITextField!
    @IBAction func reg(_ sender: Any) {
        
    }
    @IBAction func Phone(_ sender: Any) {
    }
    @IBAction func Config(_ sender: Any) {
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        mapita.showsUserLocation = true
        // Do any additional setup after loading the view.
    }


}

